public class Main{
    public static void main(String [] args){
        System.out.println("Hello git");
        System.out.println("My name is: Shahrzad");
        System.out.println("My student ID is 99243027");

    }
}
